Description:

Texture Pack made by Nanoslime because...well, he likes green.


Instructions:

1. Go to %appdata%\Cubic\dyna\images

2. Backup Store.png, Title.png and UI.png

3. Extract the files inside greenpack.zip and paste them inside %appdata%\Cubic\dyna\images (overwriting when asked).

4. Restart Cubic Castles fully.